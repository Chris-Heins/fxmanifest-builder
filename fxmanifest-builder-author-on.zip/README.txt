fxmanifest-builder (author/description ON)
=================================================

Header style it generates:

fx_version 'cerulean'
game 'gta5'
author '' 
description '' 
version '1.0.2'
lua54 'yes'
[this_is_a_map 'yes' if it detects map/MLO files]

Plus:
- shared_scripts / client_scripts / server_scripts
- ui_page + files for NUI
- data_file lines for vehicles/maps/audio
- dependency '/assetpacks' for maps/MLOs

How to use
----------
1. Install Python 3 from python.org (tick "Add python.exe to PATH").
2. Extract this zip to a folder (e.g. Desktop\fxmanifest-builder).

Option A – drag & drop:
- Drag your FiveM resource folder onto fxmanifest_builder.py

Option B – command line:
- Open CMD
- cd into the fxmanifest-builder folder
- Run:
    fxmanifest_builder.py path\to\your\resource

It will generate fxmanifest.lua inside your resource.

If you want to change author/description:
- Open fxmanifest_builder.py in a text editor.
- Edit AUTHOR and DESCRIPTION at the top and save.

Build your own EXE (optional)
-----------------------------
1. Open CMD in this folder.
2. Install PyInstaller:
       pip install pyinstaller
3. Run:
       build_exe.bat

4. Use dist\fxmanifest_builder.exe and drag & drop resources onto it.
