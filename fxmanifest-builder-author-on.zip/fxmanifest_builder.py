#!/usr/bin/env python3
"""
fxmanifest-builder
Auto-generates fxmanifest.lua for FiveM resources.

Header style:
    fx_version 'cerulean'
    game 'gta5'
    author '' 
    description '' 
    version '1.0.2'
    lua54 'yes'
    [this_is_a_map 'yes'] (auto when it sees ymap/ytyp etc)
"""

import os
import sys
from pathlib import Path

# ------- header config (DEFAULT ON) -------
USE_AUTHOR_DESCRIPTION = True   # author/description ON by default
AUTHOR = ""          # put your name here if you want
DESCRIPTION = ""     # put a short description here if you want

# ----------------- helpers -----------------

def is_lua(path: Path) -> bool:
    return path.suffix.lower() == ".lua"

def is_html_like(path: Path) -> bool:
    return path.suffix.lower() in {".html", ".htm"}

def is_nui_asset(path: Path) -> bool:
    return path.suffix.lower() in {
        ".html", ".htm", ".js", ".css",
        ".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg",
        ".ttf", ".otf", ".woff", ".woff2"
    }

def detect_root(paths):
    if not paths:
        return None
    resolved = [p.resolve() for p in paths]
    common = os.path.commonpath(resolved)
    root = Path(common)
    if root.is_file():
        root = root.parent
    return root

DATA_FILE_RULES = {
    "handling.meta": "HANDLING_FILE",
    "vehicles.meta": "VEHICLE_METADATA_FILE",
    "carcols.meta": "CARCOLS_FILE",
    "carvariations.meta": "VEHICLE_VARIATION_FILE",
    "vehiclelayouts.meta": "VEHICLE_LAYOUTS_FILE",
    "dlctext.meta": "DLC_TEXT_FILE",
    "gtxd.meta": "GTXD_PARENTING_DATA",
    "sp_manifest.ymt": "SCENARIO_POINTS_OVERRIDE_PSO_FILE",
}

def scan_resource(root: Path):
    client_scripts = []
    server_scripts = []
    shared_scripts = []
    files = []
    data_files = []
    ui_page = None
    this_is_a_map = False

    for dirpath, _, filenames in os.walk(root):
        for fname in filenames:
            p = Path(dirpath) / fname
            rel = p.relative_to(root).as_posix()
            low_name = fname.lower()
            low_rel = rel.lower()
            parts = [part.lower() for part in p.parts]

            if is_nui_asset(p):
                if rel not in files:
                    files.append(rel)
                if is_html_like(p):
                    if ui_page is None or fname.lower() == "index.html":
                        ui_page = rel

            if is_lua(p):
                if low_name == "__resource.lua":
                    shared_scripts.append(rel)
                elif "client" in low_rel:
                    client_scripts.append(rel)
                elif "server" in low_rel:
                    server_scripts.append(rel)
                elif any(key in low_rel for key in ("config", "shared", "common")):
                    shared_scripts.append(rel)
                else:
                    shared_scripts.append(rel)
                continue

            if p.suffix and rel not in files:
                files.append(rel)

            if low_name in DATA_FILE_RULES:
                dtype = DATA_FILE_RULES[low_name]
                data_files.append((dtype, rel))

            if low_name.endswith(".dat151.rel"):
                data_files.append(("AUDIO_GAMEDATA", rel))

            if p.suffix.lower() in {".ymap", ".ytyp"}:
                this_is_a_map = True
            if "stream" in parts and any(ext in low_name for ext in (".ymap", ".ytyp")):
                this_is_a_map = True

    client_scripts = sorted(set(client_scripts))
    server_scripts = sorted(set(server_scripts))
    shared_scripts = sorted(set(shared_scripts))
    files = sorted(set(files))
    data_files = sorted(set(data_files))

    return {
        "client_scripts": client_scripts,
        "server_scripts": server_scripts,
        "shared_scripts": shared_scripts,
        "files": files,
        "data_files": data_files,
        "ui_page": ui_page,
        "this_is_a_map": this_is_a_map,
    }

def build_list_block(keyword, items):
    items = [i for i in items if i]
    if not items:
        return ""
    if len(items) == 1:
        return f"{keyword} '{items[0]}'\n"
    lines = "\n".join(f"    '{i}'," for i in items)
    return f"{keyword} {{\n{lines}\n}}\n"

def build_data_file_lines(data_files):
    if not data_files:
        return ""
    lines = []
    for dtype, path in data_files:
        if dtype == "SCENARIO_POINTS_OVERRIDE_PSO_FILE":
            lines.append(f'data_file "{dtype}" "{path}"')
        else:
            lines.append(f"data_file '{dtype}' '{path}'")
    return "\n".join(lines) + "\n"

def generate_fxmanifest(root: Path, scan_result):
    out = []
    # HEADER
    out.append("fx_version 'cerulean'")
    out.append("game 'gta5'")
    if USE_AUTHOR_DESCRIPTION:
        out.append(f"author '{AUTHOR}'")
        out.append(f"description '{DESCRIPTION}'")
    out.append("version '1.0.2'")
    out.append("lua54 'yes'")

    if scan_result["this_is_a_map"]:
        out.append("this_is_a_map 'yes'")

    out.append("")

    # Scripts
    out.append(build_list_block("shared_scripts", scan_result["shared_scripts"]))
    out.append(build_list_block("client_scripts", scan_result["client_scripts"]))
    out.append(build_list_block("server_scripts", scan_result["server_scripts"]))

    # NUI
    if scan_result["ui_page"]:
        out.append(f"ui_page '{scan_result['ui_page']}'\n")

    # Files + data_files
    out.append(build_list_block("files", scan_result["files"]))
    out.append(build_data_file_lines(scan_result["data_files"]))

    # Map dependency
    if scan_result["this_is_a_map"]:
        out.append("dependency '/assetpacks'")

    manifest_text = "\n".join([part for part in out if part is not None]).strip() + "\n"
    fx_path = root / "fxmanifest.lua"
    fx_path.write_text(manifest_text, encoding="utf-8")
    return fx_path, manifest_text

def main():
    if len(sys.argv) <= 1:
        print("fxmanifest-builder (author/description ON by default)")
        print("---------------------------------------------------")
        print("Drag + drop your FiveM resource folder onto this script / EXE")
        print("or type the path below.")
        print("")
        root_input = input("Path to resource folder: ").strip().strip('\"')
        if not root_input:
            print("No path given, exiting.")
            return
        target_paths = [Path(root_input)]
    else:
        target_paths = [Path(p) for p in sys.argv[1:]]

    all_files = []
    for p in target_paths:
        if not p.exists():
            print(f"[WARN] Path does not exist: {p}")
            continue
        if p.is_dir():
            for dirpath, _, filenames in os.walk(p):
                for fname in filenames:
                    all_files.append(Path(dirpath) / fname)
        else:
            all_files.append(p)

    if not all_files:
        print("No files found, exiting.")
        return

    root = detect_root(all_files)
    if not root:
        print("Could not determine common root folder.")
        return

    print(f"Detected resource root: {root}")
    print("Scanning files...")

    scan_result = scan_resource(root)
    fx_path, manifest_text = generate_fxmanifest(root, scan_result)

    print("")
    print(f"[OK] fxmanifest.lua generated at: {fx_path}")
    print("")
    print("---------- Preview ----------")
    print(manifest_text)
    print("-----------------------------")
    input("Done. Press Enter to close...")

if __name__ == "__main__":
    main()
